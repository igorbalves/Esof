<?php

namespace JVBase\Mapper;

class Ready extends AbstractMapper
{
	
}