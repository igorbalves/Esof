<?php

namespace JVBase\Service;

class Ready extends AbstractService
{
	protected $entityMapper = 'jvbase_mapper_ready';
}